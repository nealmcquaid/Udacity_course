import media
#import the file 'media.py' (we created to contain the class for movies)

import fresh_tomatoes
#imports file to create webpage

blade_runner_2049 = media.Movie("Blade Runner 2049", "neo-noir science fiction film", "https://upload.wikimedia.org/wikipedia/en/2/27/Blade_Runner_2049_logo.png", "https://www.youtube.com/watch?v=gCcx85zbxz4")
#print(toy_story.storyline)

avatar = media.Movie("Avatar", "a marine on alien planet", "https://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg", "https://www.youtube.com/watch?v=5PSNL1qE6VY")
#print(avatar.storyline)
#avatar.show_trailer()

atomic_blonde = media.Movie("Atomic Blonde", "Jason Bourne, only female", "https://upload.wikimedia.org/wikipedia/en/b/b5/Atomic_Blonde_poster.jpg", "https://www.youtube.com/watch?v=yIUube1pSC0")
#atomic_blonde.show_trailer()

kung_fury = media.Movie("Kung Fury", "a ninja", "https://upload.wikimedia.org/wikipedia/en/0/0d/Kung_Fury_Poster.png", "https://www.youtube.com/watch?v=nO_DIwuGBnA")

guardians_of_the_galaxy_vol_2 = media.Movie("Guardians of the Galaxy Vol. 2", "Starlord adnd Groot", "https://upload.wikimedia.org/wikipedia/en/9/95/GotG_Vol2_poster.jpg", "https://www.youtube.com/watch?v=dW1BIid8Osg")

wonderwoman = media.Movie("Wonderwoman", "her", "https://upload.wikimedia.org/wikipedia/en/e/e1/Gal_Gadot_as_Wonder_Woman.jpg", "https://www.youtube.com/watch?v=INLzqh7rZ-U")

movies = [blade_runner_2049, avatar, atomic_blonde, kung_fury, guardians_of_the_galaxy_vol_2, wonderwoman]
fresh_tomatoes.open_movies_page(movies)

print(media.Movie.__doc__)
print(media.Movie.__name__)
