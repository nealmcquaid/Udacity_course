/*
This is empty on purpose! Your code to build the resume will go here.
 */




var bio = {
  "name" : "Neal",
  "role" : "web developer newbie",
  "welcomeMessage" : "Hi, this is my demo resume site for Udacity",
    "contacts" : {
    "mobile" : "+3531234567",
    "email" : "ntesting@gmail.com",
    "github" : "robinhood",
    "twitter" : "@superman",
    "blog" : "https://www.501naturalwonders.com",
    "location" : "Bridgetown, Barbados"
  },
  "skills" : [
    "awesomeness", "delivering things", "space explorer", "alien language translator"
  ],
  "bioPic" : "images/fry.jpg"
};

function displayBio() {
  $("#header").append(HTMLheaderName.replace("%data%", bio.name));
  $("#header").append(HTMLheaderRole.replace("%data%", bio.role));

  $("#topContacts").append(HTMLmobile.replace("%data%", bio.contacts.mobile));
  $("#topContacts").append(HTMLemail.replace("%data%", bio.contacts.email));
  $("#lets-connect").append(HTMLtwitter.replace("%data%", bio.contacts.twitter));
  $("#topContacts").append(HTMLgithub.replace("%data%", bio.contacts.github));
  $("#topContacts").append(HTMLblog.replace("%data%", bio.contacts.blog));
  $("#mapDiv").append(HTMLlocation.replace("%data%", bio.contacts.location));
  $("#header").append(HTMLbioPic.replace("%data%", bio.bioPic));
  // $("#header").append(HTMLwelcomeMsg.replace("%data%", bio.welcomeMsg));

  if(bio.skills.length > 0) {
    $("#header").append(HTMLskillsStart);

    var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
    $("#skills").append(formattedSkill);
    formattedSkill = HTMLskills.replace("%data%",bio.skills[1]);
    $("#skills").append(formattedSkill);
    formattedSkill = HTMLskills.replace("%data%",bio.skills[2]);
    $("#skills").append(formattedSkill);
    formattedSkill = HTMLskills.replace("%data%",bio.skills[3]);
  };
};







var work = {
  "jobs" : [
    {
      "employer" : "Savage Inc.",
      "employerURL" : "https://www.google.ie",
      "title" : "Developer",
      "location" : "Reykjavik, Iceland",
      "dates" : "1994 - 1996",
      "description" : "A cold developer of Savage projects and products"
    },
    {
      "employer" : "Tomato Ltd.",
      "employerURL" : "https://www.zomato.com/tucson-az/guilin-chinese-el-encanto/menu",
      "title" : "Guiding Light",
      "location" : "Ghuilin, China",
      "dates" : "1998 - 2011",
      "description" : "A Guiding Light for Tomatoes. Here, opportunities arose to work with developing, designing, cooking, creating, envisioning the shape and texture of tomatoes"
    },
    {
      "employer" : "BigBox Company",
      "employerURL" : "http://thebigboxco.com/",
      "title" : "Superstar",
      "location" : "Salt Lake City, USA",
      "dates" : "2011 - Future",
      "description" : "A company that makes Big Boxes. A superstar where I made Big Boxes"
    }
  ]
};

// Section that adds employment history
function displayWork() {
  for (job in work.jobs) {
    $("#workExperience").append(HTMLworkStart);

    var formattedEmployerUrl = HTMLworkEmployerUrl.replace("%data%", work.jobs[job].employerURL);
    var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[job].employer);
    var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[job].title);
    var formattedWorkDates = HTMLworkDates.replace("%data%", work.jobs[job].dates);
    var formattedWorkLocation = HTMLworkLocation.replace("%data%", work.jobs[job].location);
    var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[job].description);
    var formattedEmployerTitle = formattedEmployerUrl + formattedEmployer + formattedWorkDates + formattedWorkLocation + formattedTitle + formattedDescription;

    $(".work-entry:last").append(formattedEmployerTitle);
  }
};











// Projects JSON details, and function for integrating into page
var projects = {
  "projects" : [
    {
      "title" : "Wiki",
      "location" : "Caracas, Venezuela",
      "dates" : "1996",
      "description" : "online wiki to store all data related to systems within Vodafone",
      "images" : "https://upload.wikimedia.org/wikipedia/commons/3/30/Great_Eastern_1866-crop.jpg"
    },
    {
      "title" : "Excite.com",
      "location" : "Accra, Ghana",
      "dates" : "1996",
      "description" : "Before Yahoo or Google",
      "images" : "https://upload.wikimedia.org/wikipedia/commons/3/30/Great_Eastern_1866-crop.jpg"
    }
    ]
};

projects.display = function() {
  for (project in projects.projects) {
    $("#projects").append(HTMLprojectStart);

    var formattedTitle = HTMLprojectTitle.replace("%data%", projects.projects[project].title);
    $(".project-entry:last").append(formattedTitle);

    var formattedDates = HTMLprojectDates.replace("%data%", projects.projects[project].dates);
    $(".project-entry:last").append(formattedDates);

    var formattedDescription = HTMLprojectDescription.replace("%data%", projects.projects[project].description);
    $(".project-entry:last").append(formattedDescription);

//    if (projects.projects[project].images.length > 0) {
//      for (image in projects.projects[project].images) {
//        var formattedImage = HTMLprojectImage.replace("%data%", projects.projects[project].images[image]);
//        $(".project-entry:last").append(formattedImage);
//        }
//      }
    }
};



var education = {
  "schools": [
    {
      "name" : "Dublin City University",
      "location" : "Caracas, Venezuela",
      "dates" : "1998 - 2002",
      "degree" : "Msc",
      "url" : "http://www.dcu.ie",
      "majors" : [
        "yoga", "waves", "space travel"
      ]
    },
    {
      "name" : "Moon university",
      "location" : "Accra, Ghana",
      "dates" : "2008 - 2012",
      "degree" : "pHd",
      "url" : "http://www.themoon.ie",
      "majors" : [
        "gravity", "stars", "how to make air"
      ]
    }
  ]
};


// Section that adds Education history
education.display = function() {
  for (school in education.schools) {
    $("#education").append(HTMLschoolStart);

    var formattedName = HTMLschoolName.replace("%data%", education.schools[school].name);
    $(".education-entry:last").append(formattedName);

    var formattedLocation = HTMLschoolLocation.replace("%data%", education.schools[school].location);
    $(".education-entry:last").append(formattedLocation);

    var formattedDate = HTMLschoolDates.replace("%data%", education.schools[school].dates);
    $(".education-entry:last").append(formattedDate);

    var formattedDegree = HTMLschoolDegree.replace("%data%", education.schools[school].degree);
    $(".education-entry:last").append(formattedDegree);

    if (education.schools[school].majors.length > 0) {
      for (major in education.schools[school].majors) {
        var formattedMajors = HTMLschoolMajor.replace("%data%", education.schools[school].majors[major]);
        $(".education-entry:last").append(formattedMajors);
      }
    }
  }
};





// returns an array of locations where you worked
function locationizer(work_obj) {
  var locationArray = [];

  for (job in work_obj.jobs) {
    var newLocation = work_obj.jobs[job].location;
    locationArray.push(newLocation);
  }

  return locationArray;
};


// Changes wording of my name to capitals and all others to small
function inName(name) {
  name = name.trim().split(" ");
  console.log(name);
  name[1] = name[1].toUpperCase();
  name[0] = name[0].slice(0,1).toUpperCase() + name[0].slice(1).toLowerCase();
  return name[0] + " " + name[1];
};
$('#main').append(internationalizeButton);


// displays the Google Map
$("#mapDiv").append(googleMap);



displayBio();
displayWork();
projects.display();
education.display();
